<!--


-->



<!DOCTYPE html>
<html>
	<head>
		<title>Home Page</title>
		<script src="js/jquery-3.1.1.min.js"></script>

		<script src="js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/myStyle.css">

	</head>
<body>

<nav class="navbar navbar-inverse">
	        <div class="container">
	          <div class="navbar-header">
	            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
	              <span class="sr-only">Toggle navigation</span>
	              <span class="icon-bar"></span>
	              <span class="icon-bar"></span>
	              <span class="icon-bar"></span>
	            </button>
	            <a class="navbar-brand" href="#">UTAHackthon</a>
	          </div>
	          <div class="navbar-collapse collapse">
	            <ul class="nav navbar-nav">
           		 <li class="active"><a href="default.php">DisasterRelief</a></li>
	              <li><a href="About.php">About us</a></li>
	                  
	                </ul>
	              </li>
	             

	            </ul>
			        

	          </div>
	        </div>
        </nav>
<div class="jumbotron">
      <div class="container">
      	<div class="row">
      		<form class="form-horizontal col-md-6 span6 mycontent-left">
				<fieldset>

					<!-- Form Name -->
					<legend class="text-center">Request Help</legend>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="name">Name</label>  
					  <div class="col-md-4">
						  <input id="name" name="name" type="text" placeholder="Enter your name" class="form-control input-md" required="">
						    
					  </div>

					</div>

					<!-- phone input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="phone">Phone</label>
					  <div class="col-md-4">
					    <input id="phone" name="phone" type="phone" placeholder="Enter a phone" class="form-control input-md" required="">
					    
					  </div>
					</div>


					<!-- Urgency input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="email">Urgency</label>  
					   <div class="dropdown col-md-4">
					    <button class="btn btn-default dropdown-toggle col-md-12" type="button" id="urgency" data-toggle="dropdown">select
					    <span class="caret"></span></button>
					    <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
					      <li role="presentation"><a role="menuitem" tabindex="-1" href="#">High</a></li>
					      <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Medium</a></li>
					      <li role="presentation" ><a role="menuitem" tabindex="-1" href="#">Low</a></li>
					     
					     
					    </ul>
					  </div>
					</div>

					<!-- Button -->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="signup"></label>
					  <div class="col-md-4">
					    <button id="request" name="request" class="btn btn-success">Request</button>
					  </div>
					</div>
				</fieldset>
			</form>

			<form class="form-horizontal col-md-6 span6">
					<fieldset>

						<!-- Form Name -->
						<legend class="text-center">Volunteer</legend>

						<!-- Text input-->
						<div class="form-group">
						  <label class="col-md-4 control-label" for="name">Name</label>  
						  <div class="col-md-4">
							  <input id="name" name="name" type="text" placeholder="Enter your name" class="form-control input-md" required="">
							    
						  </div>

						</div>

						<!-- phone input-->
						<div class="form-group">
						  <label class="col-md-4 control-label" for="phone">Phone</label>
						  <div class="col-md-4">
						    <input id="phone" name="phone" type="phone" placeholder="Enter a phone" class="form-control input-md" required="">
						    
						  </div>
						</div>


						<!-- Urgency input-->
						<div class="form-group">
						  <label class="col-md-4 control-label" for="email">Availability</label>  
						   <div class="dropdown col-md-4">
						    <button class="btn btn-default dropdown-toggle col-md-12" type="button" id="menu1" data-toggle="dropdown">select
						    <span class="caret"></span></button>

						    <select>
							  <option value="volvo">Volvo</option>
							  <option value="saab">Saab</option>
							  <option value="mercedes">Mercedes</option>
							  <option value="audi">Audi</option>
							</select>
						    <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
						      <li role="presentation"><a role="menuitem" tabindex="-1" href="#">1 day<input type="hidden" id="vl" name="vl" value=""></a></li>
						      <li role="presentation"><a role="menuitem" tabindex="-1" href="#">2 day</a></li>
						      <li role="presentation" selected><a role="menuitem" tabindex="-1" href="#">3 day</a></li>
						     
						     
						    </ul>
						  </div>
						</div>

						<!-- Button -->
						<div class="form-group">
						  <label class="col-md-4 control-label" for="signup"></label>
						  <div class="col-md-4">
						    <button id="signup" name="signup" class="btn btn-success">Request</button>
						  </div>
						</div>
					</fieldset>
				</form>
      	</div>
      

      </div>
</div>




</body>
</html>
<?php
function getDB()
{
	try {	

			  $dbh = new PDO("mysql:host=127.0.0.1:3306;dbname=","root","",array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
			  
			
		 return $dbh;
		  
		} catch (PDOException $e) {
		  print "Error!: " . $e->getMessage() . "<br/>";
		  die();
		}

}


if(isset($_GET['request']))
{


try
{
 $dbh=getDB();

	 $dbh->beginTransaction();
 	$stmt = $dbh->prepare(	"INSERT INTO helpseeker (name, phone, Urgency, longitude,latitude) VALUES ('".$_GET['name']."','".$_GET['phone']."','".$_GET['urgency']."','29.681429','-95.369349)");
			 


	 $stmt->execute();

	 $dbh->commit(); 

	 echo '<div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
   			 <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
   			 <strong>Success!</strong> User registered Successfully ! Try Log in...
				</div>';


}

catch(PDOException $e) {

		echo '<div class="alert alert-danger fade in alert-dismissable">
			    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
			    <strong>Error!</strong> ' .$e->getMessage().'This alert box indicates a dangerous or potentially negative action.
			</div>';

		  die();
		}




	 




}


?>

