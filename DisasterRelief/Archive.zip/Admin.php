<!--


-->



<!DOCTYPE html>
<html>
	<head>
		<title>Home Page</title>
		<script src="js/jquery-3.1.1.min.js"></script>

		<script src="js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/myStyle.css">

	</head>
<body>

<nav class="navbar navbar-inverse">
	        <div class="container">
	          <div class="navbar-header">
	            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
	              <span class="sr-only">Toggle navigation</span>
	              <span class="icon-bar"></span>
	              <span class="icon-bar"></span>
	              <span class="icon-bar"></span>
	            </button>
	            <a class="navbar-brand" href="#">UTAHackthon</a>
	          </div>
	          <div class="navbar-collapse collapse">
	            <ul class="nav navbar-nav">
           		 <li class="active"><a href="default.php">DisasterRelief</a></li>
	              <li><a href="About.php">About us</a></li>
	              <!-- <li class="dropdown">
	                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Pages <span class="caret"></span></a>
	                <ul class="dropdown-menu">
	                  	<li><a href="Part01_ArtistsDataList.php">Artist Data List</a></li>
                        <li><a href="Part02_SingleArtist.php?id=19">Single Artist</a></li>
                   		<li><a href="Part03_SingleWork.php?id=394">Single Work</a></li>
	                  
	                  	<li><a href="Part04_Search.php">Search</a></li> -->
	                  
	                </ul>
	              </li>
	             

	            </ul>
			        


	            <!-- <form class="navbar-form navbar-right" action="Part04_Search.php?title=" method="get">

			        <div class="form-group">
			        <p class="name"><a href="About.php"  >Alagiya, Ravi R</a></p>

			          <input type="text" class="form-control" placeholder="Search Paintings" name="title">
			        	</div>
            		  <button type="submit" class="btn btn btn-info">Search</button>

      			</form> -->
	          </div><!--/.nav-collapse -->
	        </div>
        </nav>
<div class="jumbotron">
      <div class="container">
      	<div class="row">
      		<form class="form-horizontal col-md-6 span6 mycontent-left">
				<fieldset>

					<!-- Form Name -->
					<legend class="text-center">Request Help</legend>

					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="name">Name</label>  
					  <div class="col-md-4">
						  <input id="name" name="name" type="text" placeholder="Enter your name" class="form-control input-md" required="">
						    
					  </div>

					</div>

					


					<!-- phone input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="phone">Phone</label>
					  <div class="col-md-4">
					    <input id="phone" name="phone" type="phone" placeholder="Enter a phone" class="form-control input-md" required="">
					    
					  </div>
					</div>


					<!-- Urgency input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="email">Urgency</label>  
					   <div class="dropdown col-md-4">
					    <button class="btn btn-default dropdown-toggle col-md-12" type="button" id="menu1" data-toggle="dropdown">select
					    <span class="caret"></span></button>
					    <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
					      <li role="presentation"><a role="menuitem" tabindex="-1" href="#">High</a></li>
					      <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Medium</a></li>
					      <li role="presentation" selected><a role="menuitem" tabindex="-1" href="#">Low</a></li>
					     
					     
					    </ul>
					  </div>
					</div>

					<!-- Button -->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="signup"></label>
					  <div class="col-md-4">
					    <button id="signup" name="signup" class="btn btn-success">Request</button>
					  </div>
					</div>
				</fieldset>
			</form>

			<form class="form-horizontal col-md-6 span6">
					<fieldset>

						<!-- Form Name -->
						<legend class="text-center">Volunteer</legend>

						<!-- Text input-->
						<div class="form-group">
						  <label class="col-md-4 control-label" for="name">Name</label>  
						  <div class="col-md-4">
							  <input id="name" name="name" type="text" placeholder="Enter your name" class="form-control input-md" required="">
							    
						  </div>

						</div>

						<!-- phone input-->
						<div class="form-group">
						  <label class="col-md-4 control-label" for="phone">Phone</label>
						  <div class="col-md-4">
						    <input id="phone" name="phone" type="phone" placeholder="Enter a phone" class="form-control input-md" required="">
						    
						  </div>
						</div>


						<!-- Urgency input-->
						<div class="form-group">
						  <label class="col-md-4 control-label" for="email">Availability</label>  
						   <div class="dropdown col-md-4">
						    <button class="btn btn-default dropdown-toggle col-md-12" type="button" id="menu1" data-toggle="dropdown">select
						    <span class="caret"></span></button>
						    <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
						      <li role="presentation"><a role="menuitem" tabindex="-1" href="#">1 day</a></li>
						      <li role="presentation"><a role="menuitem" tabindex="-1" href="#">2 day</a></li>
						      <li role="presentation" selected><a role="menuitem" tabindex="-1" href="#">3 day</a></li>
						     
						     
						    </ul>
						  </div>
						</div>

						<!-- Button -->
						<div class="form-group">
						  <label class="col-md-4 control-label" for="signup"></label>
						  <div class="col-md-4">
						    <button id="signup" name="signup" class="btn btn-success">Request</button>
						  </div>
						</div>
					</fieldset>
				</form>
      	</div>
      

      </div>
</div>




</body>
</html>

